#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int func(int i);
