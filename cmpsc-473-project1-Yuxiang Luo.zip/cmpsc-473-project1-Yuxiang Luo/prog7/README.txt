I have changed prog71.c a little bit to prog71_sleepmore.c, make it sleep longer before sending the signal,
so I have some time operating in GDB.

I uses gdb ./prog71_sleepmore to get the result.